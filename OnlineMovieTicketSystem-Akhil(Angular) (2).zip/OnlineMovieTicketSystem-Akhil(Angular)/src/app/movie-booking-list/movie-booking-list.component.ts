import { Component, OnInit } from '@angular/core';
import { MovieService, Booking } from '../service/movie.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-movie-booking-list',
  templateUrl: './movie-booking-list.component.html',
  styleUrls: ['./movie-booking-list.component.css']
})
export class MovieBookingListComponent implements OnInit {

  bookings : Booking[];

  constructor(private service: MovieService , private router : Router) { }

  ngOnInit(): void {
      this.service.getAllBookings().subscribe(
          response =>this.handleSuccessfulResponse(response),
      );
   }
  
   handleSuccessfulResponse(response){     
    this.bookings=response; 
  }

  cancelBooking(booking: Booking): void {
        this.service.cancelBooking(booking).subscribe( data => {
              this.bookings = this.bookings.filter(u => u !== booking);
              alert("Booking Cancelled Successfully");
        });
      this.router.navigate(['/bookinglist']);
   }

   


}
