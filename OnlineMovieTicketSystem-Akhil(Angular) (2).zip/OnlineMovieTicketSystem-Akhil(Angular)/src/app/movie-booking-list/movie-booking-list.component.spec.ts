import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MovieBookingListComponent } from './movie-booking-list.component';

describe('MovieBookingListComponent', () => {
  let component: MovieBookingListComponent;
  let fixture: ComponentFixture<MovieBookingListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MovieBookingListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MovieBookingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
