import { Component, OnInit } from '@angular/core';
import { MovieService,Booking, Movie } from '../service/movie.service';
import { Router } from '@angular/router';
import { MoviedetailsService } from './moviedetails.service';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent implements OnInit {

  movies: Movie[];
  
  constructor(private service: MovieService ,private router: Router ,private service1 : MoviedetailsService) 
  { }

  ngOnInit(){
      this.movies = this.service.getMovies();
  }
  
  //Using Service1 to send movie and theatre details 
  bookMovie(movie : Movie):void{
     this.service1.sendMovieDetails(movie);
     this.router.navigate(['/bookmovie']);
  }
}   