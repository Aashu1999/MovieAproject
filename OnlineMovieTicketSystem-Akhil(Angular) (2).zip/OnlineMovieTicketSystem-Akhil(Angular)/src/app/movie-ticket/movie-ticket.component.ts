import { Component, OnInit } from '@angular/core';
import { MovieService, Booking } from '../service/movie.service';

export interface Booking1{
  bookingId:number,
  movieName:string,
  theatreName:string,
  customerName:string,
  emailId:string,
  phno:string,
  paymentMethod:string,
  seats:number 
  toString() :string
}

@Component({
  selector: 'app-movie-ticket',
  templateUrl: './movie-ticket.component.html',
  styleUrls: ['./movie-ticket.component.css']
})
export class MovieTicketComponent implements OnInit {
  
  booking : Booking = new Booking(0,"","","","","","",0);
  public booking1 : Booking1 ;
  constructor(private service: MovieService) { }

  ngOnInit(){
      this.service.$bookingDetails.subscribe( (data) => {
        this.booking1 = data ;
        console.log(this.booking1);
       
      })
  }
  settoString(){
    this.booking1.toString = function() {
      return 'your name is ${this.customerName}' ;
    }   
  }
}
