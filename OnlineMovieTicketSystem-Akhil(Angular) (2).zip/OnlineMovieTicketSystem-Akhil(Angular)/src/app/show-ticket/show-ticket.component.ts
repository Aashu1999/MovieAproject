import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MovieService } from '../service/movie.service';

@Component({
  selector: 'app-show-ticket',
  templateUrl: './show-ticket.component.html',
  styleUrls: ['./show-ticket.component.css']
})
export class ShowTicketComponent implements OnInit {
   
  id : any;
  booking : any;

  constructor(private route : ActivatedRoute , private service: MovieService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.showTicket();
  }

  showTicket(){
    this.service.showTicket(this.id).subscribe( data => {
          this.booking = data;
    })
  }

}
