import { Component, OnInit } from '@angular/core';
import { Booking, MovieService, Movie } from '../service/movie.service';
import { Router } from '@angular/router';
import { MoviedetailsService } from '../movie-list/moviedetails.service';


@Component({
  selector: 'app-movie-booking',
  templateUrl: './movie-booking.component.html',
  styleUrls: ['./movie-booking.component.css']
})
export class MovieBookingComponent implements OnInit {

  public movie: Movie =new Movie("","");
  bookingfinal : Booking = new Booking(0,"","","","","","",0); 
  
  
  constructor(private service: MovieService , private router: Router ,private service1 : MoviedetailsService) {

  }


  ngOnInit() {
      
        //Collecting emitted data
        this.service1.$movieDetails.subscribe( (data) => {
           this.movie = data ;
           console.log("Particular Movie And Theatre Received",this.movie); 
           this.service.setMovieDetails(this.movie); 
        });
  
  }

  createBooking():void{
    this.service.createBooking(this.bookingfinal).subscribe( data => { alert("Booking created successfully.");});
  }

 
}
